import java.sql.*;

public class App {
    public static void main(String[] args) {
        try {
            // Registering the driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Creating a connection
            String url = "jdbc:mysql://localhost:3306/bookstore";
            String username = "root";
            String password = "";
            Connection con = DriverManager.getConnection(url, username, password);

            // Creating a table for books
            String query = "CREATE TABLE books (id INT AUTO_INCREMENT PRIMARY KEY, title VARCHAR(255), author VARCHAR(255), price INT)";
            Statement stmt = con.createStatement();
            stmt.executeUpdate(query);

            // Creating a table for customers
            query = "CREATE TABLE customers (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255), address VARCHAR(255), bill INT)";
            stmt.executeUpdate(query);

            // Inserting records in books
            query = "INSERT INTO books (title, author, price) VALUES ('The Alchemist', 'Paulo Coelho', 170)";
            stmt.executeUpdate(query);
            query = "INSERT INTO books (title, author, price) VALUES ('The Da Vinci Code', 'Dan Brown', 120)";
            stmt.executeUpdate(query);
            query = "INSERT INTO books (title, author, price) VALUES (' Catcher ', 'J.D', 67)";
            stmt.executeUpdate(query);
            query = "INSERT INTO books (title, author, price) VALUES ('T', 'J.D. Salinger', 900)";
            stmt.executeUpdate(query);
            query = "INSERT INTO books (title, author, price) VALUES ('One Hundred', 'Gabriel Garcia Marquez', 305)";
            stmt.executeUpdate(query);
            query = "INSERT INTO books (title, author, price) VALUES ('The Hobbit', 'J.R.R. Tolkien', 220)";
            stmt.executeUpdate(query);
            query = "INSERT INTO books (title, author, price) VALUES ('Lord of the Rings', 'J.R.R. Tolkien', 459)";
            stmt.executeUpdate(query);
            query = "INSERT INTO books (title, author, price) VALUES ('The Odyssey', 'Homer', 145)";
            stmt.executeUpdate(query);
            query = "INSERT INTO books (title, author, price) VALUES ('Harry Potter ', 'J.K. Rowling', 875)";
            stmt.executeUpdate(query);
            query = "INSERT INTO books (title, author, price) VALUES ('Catcher in the Rye', 'J.D. Salinger', 900)";
            stmt.executeUpdate(query);

            // Inserting records in customers
            query = "INSERT INTO customers (name, address, bill) VALUES ('Ravi', 'Patna', 100)";
            stmt.executeUpdate(query);
            query = "INSERT INTO customers (name, address, bill) VALUES ('Vansh', 'GAya', 2650)";
            stmt.executeUpdate(query);
            query = "INSERT INTO customers (name, address, bill) VALUES ('Amit', 'Lalitpur', 345)";
            stmt.executeUpdate(query);

            // Updating records
            query = "UPDATE books SET price = 110 WHERE title = 'The Alchemist'";
            stmt.executeUpdate(query);

            // Deleting records
            query = "DELETE FROM books WHERE title = 'T'";
            stmt.executeUpdate(query);

            // Retrieving records from books
            query = "SELECT * FROM books";
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                System.out.println(rs.getInt("id") + " " + rs.getString("title") + " " + rs.getString("author") + " "
                        + rs.getFloat("price"));
            }

            // Closing the connection
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
